import java.util.Random;
import java.util.Scanner;

class Mancala {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the default number of stones per hole (mini 3 ,max 4):");
        int defaultStones = scanner.nextInt();
        if (defaultStones < 3 || defaultStones > 4) {
            System.out.println("Invalid input. Using default 4 stones per hole.");
            defaultStones = 4;
        }

        System.out.println("Select game mode:");
        System.out.println("1. Traditional");
        System.out.println("2. Arcade");
        int gameModeChoice = scanner.nextInt();

        MancalaGame game;
        if (gameModeChoice == 1) {
            game = new MancalaGame(GameMode.TRADITIONAL, defaultStones);
        } else {
            game = new MancalaGame(GameMode.ARCADE, defaultStones);
        }

        game.play();
    }

}

enum GameMode {
    TRADITIONAL, ARCADE
}

class MancalaGame {

    private static final int MIN_STONES = 3; // Added minStones constant
    private static final int MAX_STONES = 4; // Added maxStones constant
    private static final int NUM_HOLES = 6;
    private static final int PLAYER_ONE_STORE = NUM_HOLES;
    private static final int PLAYER_TWO_STORE = NUM_HOLES * 2 + 1;
    private static final int PLAYER_ONE = 1;
    private static final int PLAYER_TWO = 2;

    private final int[] board;
    private final GameMode gameMode;
    private int currentPlayer;
    private int otherPlayer;
    private final Random random;

    static {
        new Random();
    }

    public MancalaGame(GameMode gameMode, int defaultStones) {
        this.gameMode = gameMode;
        random = new Random(); // Initialize random before using it
        board = new int[NUM_HOLES * 2 + 2];
        for (int i = 0; i < board.length; i++) {
            if (i != PLAYER_ONE_STORE && i != PLAYER_TWO_STORE) {
                if (gameMode == GameMode.ARCADE) { // Added condition to initialize board with random stones
                    board[i] = random.nextInt(MAX_STONES - MIN_STONES + 1) + MIN_STONES;
                } else {
                    board[i] = defaultStones;
                }
            }
        }
        currentPlayer = random.nextInt(2) + 1; // Use random variable after it is initialized
        otherPlayer = currentPlayer == PLAYER_ONE ? PLAYER_TWO : PLAYER_ONE;
    }


    public void play() {
        while (!isGameOver(board)) {
            if (gameMode == GameMode.ARCADE) {
                activatePowerUp(board, currentPlayer);
            }
            displayBoard(board);
            int move = getPlayerMove(board, currentPlayer);
            makeMove(board, move, currentPlayer);
            if (gameMode == GameMode.ARCADE) {
                applySpecialStone(board, currentPlayer, move);
            }
            if (isExtraTurn(board, currentPlayer, move)) {
                System.out.println("Player " + currentPlayer + " gets an extra turn!");
            } else {
                currentPlayer = otherPlayer;
                otherPlayer = currentPlayer == PLAYER_ONE ? PLAYER_TWO : PLAYER_ONE;
            }
        }


        displayBoard(board);
        int playerOneCount = board[PLAYER_ONE_STORE];
        int playerTwoCount = board[PLAYER_TWO_STORE];

        if (playerOneCount > playerTwoCount) {
            System.out.println("Player 1 wins!");
        } else if (playerTwoCount > playerOneCount) {
            System.out.println("Player 2 wins!");
        } else {
            System.out.println("Tie game!");
        }
    }

    private boolean reverseTurnActivated = false;
    private boolean isExtraTurn(int[] board, int currentPlayer, int move) {
        int i = move;
        i = reverseTurnActivated ? (i - 1 + board.length) % board.length : (i + 1) % board.length;
        int stones = board[i];
        board[i] = 0;
        while (stones > 0) {
            i = (i + 1) % board.length;
            if (i != (currentPlayer == PLAYER_ONE ? PLAYER_TWO_STORE : PLAYER_ONE_STORE)) {
                stones--;
                board[i]++;
            }
        }

        int lastHoleIndex = i;

        return lastHoleIndex == (currentPlayer == PLAYER_ONE ? PLAYER_ONE_STORE : PLAYER_TWO_STORE);
    }


    private void makeMove(int[] board, int move, int currentPlayer) {
        int i = move;
        i = reverseTurnActivated ? (i - 1 + board.length) % board.length : (i + 1) % board.length;
        int stones = board[i];
        board[i] = 0;
        while (stones > 0) {
            i = (i + 1) % board.length;
            if (i != (currentPlayer == PLAYER_ONE ? PLAYER_TWO_STORE : PLAYER_ONE_STORE)) {
                stones--;
                board[i]++;
            }
        }

        int lastHoleIndex = i;

        if (lastHoleIndex != PLAYER_ONE_STORE && lastHoleIndex != PLAYER_TWO_STORE) {
            boolean isCurrentPlayerHole = (currentPlayer == PLAYER_ONE && lastHoleIndex < PLAYER_ONE_STORE)
                    || (currentPlayer == PLAYER_TWO && lastHoleIndex > PLAYER_ONE_STORE);

            if (isCurrentPlayerHole && board[lastHoleIndex] == 1) {
                int oppositeHoleIndex = (NUM_HOLES - 1) - lastHoleIndex + (currentPlayer == PLAYER_ONE ? PLAYER_TWO_STORE : 0);
                board[currentPlayer == PLAYER_ONE ? PLAYER_ONE_STORE : PLAYER_TWO_STORE] += board[oppositeHoleIndex];
                board[oppositeHoleIndex] = 0;
            }
        }
    }


    private boolean isGameOver(int[] board) {
        boolean playerOneSideEmpty = true;
        boolean playerTwoSideEmpty = true;
        for (int i = 0; i < NUM_HOLES; i++) {
            if (board[i] != 0) {
                playerOneSideEmpty = false;
            }
            if (board[i + NUM_HOLES + 1] != 0) {
                playerTwoSideEmpty = false;
            }
        }
        return playerOneSideEmpty || playerTwoSideEmpty;
    }

    private void displayBoard(int[] board) {
        System.out.println("-----------------------");
        System.out.print("| P2 | ");
        for (int i = NUM_HOLES; i > 0; i--) {
            System.out.print(board[i - 1] + " | ");
        }
        System.out.println("  |");
        System.out.print("|    | ");
        for (int i = 0; i < NUM_HOLES; i++) {
            System.out.print("  |");
        }
        System.out.println();
        System.out.print("| " + board[PLAYER_TWO_STORE] + " | ");
        for (int i = 0; i < NUM_HOLES; i++) {
            System.out.print(board[i + NUM_HOLES + 1] + " | ");
        }
        System.out.print(board[PLAYER_ONE_STORE] + " |");
        System.out.println();
        System.out.println("-----------------------");
    }

    private int getPlayerMove(int[] board, int currentPlayer) {
        Scanner scanner = new Scanner(System.in);
        int move = -1;
        while (move < 0) {
            System.out.print("Player " + currentPlayer + ", choose a hole (1-" + NUM_HOLES + "): ");
            move = scanner.nextInt() - 1;
            int startingIndex = (currentPlayer == PLAYER_ONE) ? 0 : (NUM_HOLES + 1);
            if (move < 0 || move > NUM_HOLES - 1 || board[startingIndex + move] == 0) {
                System.out.println("Invalid move. Try again.");
                move = -1;
            }
        }
        return ((currentPlayer == PLAYER_ONE) ? 0 : (NUM_HOLES + 1)) + move;
    }


    private void activatePowerUp(int[] board, int currentPlayer) {
        Scanner scanner = new Scanner(System.in);
        boolean powerUpUsed = false;

        while (!powerUpUsed) {
            System.out.println("Do you want to use a power-up? (Y/N)");
            String response = scanner.nextLine();

            if (response.equalsIgnoreCase("Y")) {
                System.out.println("Which power-up do you want to use? (C/D)");
                String powerUp = scanner.nextLine();

                if (powerUp.equalsIgnoreCase("C")) {
                    System.out.println("Continue Turn power-up used");
                    powerUpUsed = true;
                } else if (powerUp.equalsIgnoreCase("D")) {
                    System.out.println("Double Points power-up used");
                    board[currentPlayer == PLAYER_ONE ? PLAYER_ONE_STORE : PLAYER_TWO_STORE] += board[currentPlayer == PLAYER_ONE ? PLAYER_ONE_STORE : PLAYER_TWO_STORE];
                    powerUpUsed = true;
                } else {
                    System.out.println("Invalid power-up. Try again.");
                }
            } else if (response.equalsIgnoreCase("N")) {
                powerUpUsed = true;
            } else {
                System.out.println("Invalid input. Try again.");
            }
        }
    }

    private void applySpecialStone(int[] board, int currentPlayer, int move) {
        if (random.nextInt(10) == 0) {
            int specialStoneType = random.nextInt(3);

            switch (specialStoneType) {
                case 0 -> {
                    int stones = board[move];
                    int halfStones = (int) Math.ceil(stones / 2.0);
                    board[move] = halfStones;
                    System.out.println("Half hand activated: " + halfStones + " stones will be picked up");
                }
                case 1 -> {
                    System.out.println("Reverse turn activated: next turn will move clockwise");
                    reverseTurnActivated = !reverseTurnActivated;
                }
                case 2 -> {
                    System.out.println("Switch sides activated: taking stones from the opposite side");
                    int oppositeSide = currentPlayer == PLAYER_ONE ? PLAYER_TWO_STORE : PLAYER_ONE_STORE;
                    int stonesInOppositeSide = board[oppositeSide];
                    board[oppositeSide] = 0;
                    int oppositeHoleIndex = (NUM_HOLES - 1) - move + oppositeSide;
                    makeMove(board, oppositeHoleIndex, currentPlayer);
                    board[oppositeSide] = stonesInOppositeSide;
                }
            }
        }
    }
}
